

#include <iostream>
#include <string> 
#include <fstream>
#include<ios>
#include<limits>

using namespace std;

void addApplication();         void viewApplication();
void addParentRegistration();  void viewParentRegistration();
void addStaffRegistration();   void viewStaffRegistration();
void addOrderScreen();         void viewOrderScreen();
void addComplaintData();       void viewComplaintData();
void addAdminData();           void viewAdminData();
void addParentScreenData();    void viewParentScreenData();








int main()
{

    cout << "                           WELCOME T0 SCHOOL LUNCH ORDER SYSTEM             " << endl;
    cout << "    ______________________________________________________________________________ " << std::endl;
    cout << "   |                                 Contact Us                                   |" << std::endl;
    cout << "   |                                                                              |" << std::endl;
    cout << "   |       HR Department                              Catering Services           |" << std::endl;
    cout << "   |  Phone : 027 123 4567                          Phone : 027 123 4567          |" << std::endl;
    cout << "   |  Email : hrdep@example.com                     Email : catering@example.com  |" << std::endl;
    cout << "   |______________________________________________________________________________|" << std::endl;

    char choice;
    do {
        cout << "  \n   Press 1 to add application  data" << endl;
        cout << "   Press 2 to view application data" << endl;
        cout << "   Press 3 to add parent registration data" << endl;
        cout << "   Press 4 to view parent registration data" << endl;
        cout << "   Press 5 to add staff registration data" << endl;
        cout << "   Press 6 to view staff registration data" << endl;
        cout << "   press 7 to add order screen" << endl;
        cout << "   press 8 to view order screen " << endl;
        cout << "   press 9 to add complain data " << endl;
        cout << "   press 10 to view complain data " << endl;
        cout << "   press 11 to add admin  data " << endl;
        cout << "   press 12 to view admin data " << endl;
        cout << "   press 13 to add parent screen  data " << endl;
        cout << "   press 14 to view parent screen data " << endl;
        cout << "   press C to exit " << endl;
        cin >> choice;
        switch (choice) {
        case '1':
            addApplication();
            break;
        case '2':
            viewApplication();
            break;
        case '3':
            addParentRegistration();
            break;
        case '4':
            viewParentRegistration();
            break;
        case '5':
            addStaffRegistration();
            break;
        case '6':
            viewStaffRegistration();
            break;
        case'7':
            addOrderScreen();
            break;
        case '8':
            viewOrderScreen();
            break;
        case'9':
            addComplaintData();
            break;
        case '10':
            viewComplaintData();
            break;
        case'11':
            addAdminData();
            break;
        case '12':
            viewAdminData();
            break;
        case'13':
            addParentScreenData();
            break;
        case '14':
            viewParentScreenData();
            break;
        case 'c':
        case'C':
            exit(0);
            break;
        default:
            cout << "You entered a wrong input!" << endl;
            system("cls");
        }
    } while (choice != 'y');


    return 0;
}






struct Student {
    char fullName[100]; char weeklyMenu[1000]; char bookingDiscount[100];
};

void addApplication() {
    system("cls");
    int numStudent;
    struct Student List[200];
    fstream ApplicantLunchOrdering;

    ApplicantLunchOrdering.open("student.txt", ios::app);

    cout << " How many Customer lunch order do you want to add?\n";
    cin >> numStudent;
    for (int i = 0; i < numStudent; i++) {

        cout << "enter Customer Full Name " << i + 1 << endl;
        cin >> List[i].fullName;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        cout << "Write a list of  weekly menu you want ? " << i + 1 << endl;
        cin >> List[i].weeklyMenu;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        cout << "Write down how much discount you want for bulk booking " << i + 1 << endl;
        cin >> List[i].bookingDiscount;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        ApplicantLunchOrdering << List[i].fullName << "           " << List[i].weeklyMenu << "           " << List[i].bookingDiscount << "           " << endl;
        ApplicantLunchOrdering.close();
    }
}


void viewApplication() {
    system("cls");

    fstream ApplicantLunchOrdering;
    ApplicantLunchOrdering.open("student.txt", ios::in);
    if (ApplicantLunchOrdering.is_open()) {
        string line;
        while (getline(ApplicantLunchOrdering, line)) {
            cout << line << endl;
        }
        ApplicantLunchOrdering.close();
    }
}





struct Parent {
    char p_fullName[50]; char p_Gender[50]; int p_Dob; int p_Contactno; char c_fullName[50]; int c_RoomNo; int p_VisaCardNo;
    char p_VisaExpiry[50];
};

void  addParentRegistration() {
    system("cls");
    int numParent;
    struct Parent List[200];
    fstream ApplicantLunchOrdering;

    ApplicantLunchOrdering.open("Parent.txt", ios::app);
    cout << " How many parent registration you want to fillup ?\n";
    cin >> numParent;
    for (int i = 0; i < numParent; i++) {

        cout << "enter Parent Full Name " << i + 1 << endl;
        cin >> List[i].p_fullName;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        cout << "Parent Gender " << i + 1 << endl;
        cin >> List[i].p_Gender;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        cout << "Parent date of birth " << i + 1 << endl;
        cin >> List[i].p_Dob;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        cout << "enter contact number " << i + 1 << endl;
        cin >> List[i].p_Contactno;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        cout << " enter your Child full name " << i + 1 << endl;
        cin >> List[i].c_fullName;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        cout << "Child room number " << i + 1 << endl;
        cin >> List[i].c_RoomNo;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        cout << "Please enter your visa card number  " << i + 1 << endl;
        cin >> List[i].p_VisaCardNo;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        cout << "Enter the expiry date of your visa" << i + 1 << endl;
        cin >> List[i].p_VisaExpiry;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        ApplicantLunchOrdering << List[i].p_fullName << "  " << List[i].p_Gender << "  " << List[i].p_Dob << "   " << List[i].p_Contactno << "   " << List[i].c_fullName << "   "
            << List[i].c_RoomNo << "   " << List[i].p_VisaCardNo << "   " << List[i].p_VisaExpiry << "   " << endl;

        ApplicantLunchOrdering.close();
    }
}


void viewParentRegistration() {
    system("cls");

    fstream ApplicantLunchOrdering;
    ApplicantLunchOrdering.open("Parent.txt", ios::in);
    if (ApplicantLunchOrdering.is_open()) {
        string line;
        while (getline(ApplicantLunchOrdering, line)) {
            cout << line << endl;
        }
        ApplicantLunchOrdering.close();
    }
}





struct staff {
    char s_fullName[50]; char s_Gender[50]; int s_Dob;  int s_VisaCardNo; char s_VisaExpiry[50];
};

void addStaffRegistration() {
    system("cls");
    int numStaff;
    struct staff List[200];
    fstream ApplicantLunchOrdering;

    ApplicantLunchOrdering.open("Staff.txt", ios::app);
    cout << " How many Staff registration you want to fillup?\n";
    cin >> numStaff;
    for (int i = 0; i < numStaff; i++) {

        cout << "enter staff Full Name " << i + 1 << endl;
        cin >> List[i].s_fullName;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        cout << "staff Gender " << i + 1 << endl;
        cin >> List[i].s_Gender;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        cout << "staff date of birth " << i + 1 << endl;
        cin >> List[i].s_Dob;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        cout << "Please enter your visa card number  " << i + 1 << endl;
        cin >> List[i].s_VisaCardNo;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        cout << "Enter the expiry date of your visa" << i + 1 << endl;
        cin >> List[i].s_VisaExpiry;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');


        ApplicantLunchOrdering << List[i].s_fullName << "  " << List[i].s_Gender << "  " << List[i].s_Dob << "   " << List[i].s_VisaCardNo << "   " << List[i].s_VisaExpiry << "   " << endl;

        ApplicantLunchOrdering.close();
    }
}

void viewStaffRegistration() {
    system("cls");

    fstream ApplicantLunchOrdering;
    ApplicantLunchOrdering.open("Staff.txt", ios::in);
    if (ApplicantLunchOrdering.is_open()) {
        string line;
        while (getline(ApplicantLunchOrdering, line)) {
            cout << line << endl;
        }
        ApplicantLunchOrdering.close();
    }
}





struct order {
    char o_itemName[50]; int o_quantity; int o_price; char o_childName[50]; int o_classRoom; char o_status[50]; char o_diatery[50];
};


void addOrderScreen() {
    system("cls");
    int numorder;
    struct order List[200];
    fstream ApplicantLunchOrdering;

    ApplicantLunchOrdering.open("order.txt", ios::app);
    cout << " How many Order you want ?\n";
    cin >> numorder;
    for (int i = 0; i < numorder; i++) {

        cout << "enter the order item name " << i + 1 << endl;
        cin >> List[i].o_itemName;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        cout << " how many quantity you want " << i + 1 << endl;
        cin >> List[i].o_quantity;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        cout << "price for the order " << i + 1 << endl;
        cin >> List[i].o_price;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        cout << "Please enter your child name" << i + 1 << endl;
        cin >> List[i].o_childName;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        cout << "Enter the your child classroom number " << i + 1 << endl;
        cin >> List[i].o_classRoom;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        cout << "order status paid/ not paid " << i + 1 << endl;
        cin >> List[i].o_status;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        cout << "Enter the your diatery requirement for the order " << i + 1 << endl;
        cin >> List[i].o_diatery;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        ApplicantLunchOrdering << List[i].o_itemName << "  " << List[i].o_quantity << "  " << List[i].o_price << "   " << List[i].o_childName << "   "
            << List[i].o_classRoom << "   " << List[i].o_status << "   " << List[i].o_diatery << "   " << endl;

        ApplicantLunchOrdering.close();
    }
}

void viewOrderScreen() {
    system("cls");

    fstream ApplicantLunchOrdering;
    ApplicantLunchOrdering.open("order.txt", ios::in);
    if (ApplicantLunchOrdering.is_open()) {
        string line;
        while (getline(ApplicantLunchOrdering, line)) {
            cout << line << endl;
        }
        ApplicantLunchOrdering.close();
    }

}




struct complain {
    int c_number; char c_fullName[50]; char c_date[50]; char c_item[50]; char c_complain[50]; int c_contact; char c_email[50];
};

void addComplaintData() {
    system("cls");
    int numcomplain;
    struct complain List[200];
    fstream ApplicantLunchOrdering;

    ApplicantLunchOrdering.open("complain.txt", ios::app);
    cout << " How many Order you want ?\n";
    cin >> numcomplain;
    for (int i = 0; i < numcomplain; i++) {

        cout << "enter the complain number " << i + 1 << endl;
        cin >> List[i].c_number;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        cout << "enter the full name  " << i + 1 << endl;
        cin >> List[i].c_fullName;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        cout << "date of the complain " << i + 1 << endl;
        cin >> List[i].c_date;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        cout << " item ordered" << i + 1 << endl;
        cin >> List[i].c_item;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        cout << "write down your complain description " << i + 1 << endl;
        cin >> List[i].c_complain;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        cout << "enter your contact number " << i + 1 << endl;
        cin >> List[i].c_contact;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        cout << "Enter your email address " << i + 1 << endl;
        cin >> List[i].c_email;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        ApplicantLunchOrdering << List[i].c_number << "  " << List[i].c_fullName << "  " << List[i].c_date << "   " << List[i].c_item
            << "   " << List[i].c_complain << "   " << List[i].c_contact << "   " << List[i].c_email << "   " << endl;

        ApplicantLunchOrdering.close();
    }
}

void viewComplaintData() {
    system("cls");

    fstream ApplicantLunchOrdering;
    ApplicantLunchOrdering.open("complain.txt", ios::in);
    if (ApplicantLunchOrdering.is_open()) {
        string line;
        while (getline(ApplicantLunchOrdering, line)) {
            cout << line << endl;
        }
        ApplicantLunchOrdering.close();
    }
}





struct admin {
    int a_date; char a_name[50]; int a_price; char a_order[50]; int a_number; int a_amount;
    char a_name2[50]; int a_contact; int a_date2;
};

void addAdminData() {
    system("cls");
    int numadmin;
    struct admin List[200];
    fstream ApplicantLunchOrdering;

    ApplicantLunchOrdering.open("admin.txt", ios::app);
    cout << " How many student record you want write ?\n";
    cin >> numadmin;
    for (int i = 0; i < numadmin; i++) {

        cout << "enter the date for the menu you order " << i + 1 << endl;
        cin >> List[i].a_date;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        cout << "enter the item name you order  " << i + 1 << endl;
        cin >> List[i].a_name;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        cout << "enter the price for small/medium/large that you order " << i + 1 << endl;
        cin >> List[i].a_price;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        cout << " enter the number  order of sales report" << i + 1 << endl;
        cin >> List[i].a_order;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        cout << "enter the date of sales report" << i + 1 << endl;
        cin >> List[i].a_number;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        cout << "enter the amount received of sales report " << i + 1 << endl;
        cin >> List[i].a_amount;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        cout << "enter the person fullname for pending payment " << i + 1 << endl;
        cin >> List[i].a_name;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        cout << " enter the contact number of the pending payment " << i + 1 << endl;
        cin >> List[i].a_contact;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        cout << "enter the date order for pending payment " << i + 1 << endl;
        cin >> List[i].a_date2;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        ApplicantLunchOrdering << List[i].a_date << "  " << List[i].a_name << "  " << List[i].a_price << "   " << List[i].a_order << "   "
            << List[i].a_number << "   " << List[i].a_amount << "   " << List[i].a_name2 << "   " << List[i].a_contact << "   " << List[i].a_date2 << "  " << endl;

        ApplicantLunchOrdering.close();
    }
}

void viewAdminData() {
    system("cls");

    fstream ApplicantLunchOrdering;
    ApplicantLunchOrdering.open("admin.txt", ios::in);
    if (ApplicantLunchOrdering.is_open()) {
        string line;
        while (getline(ApplicantLunchOrdering, line)) {
            cout << line << endl;
        }
        ApplicantLunchOrdering.close();
    }

}






struct screendata {
    char d_menu[50]; char d_fullName[50]; char d_date[50]; char d_item[50]; char d_complain[50]; int d_contact; char d_email[50];
};

void addParentScreenData() {
    system("cls");
    int data;
    struct screendata List[200];
    fstream ApplicantLunchOrdering;

    ApplicantLunchOrdering.open("parentscreen.txt", ios::app);
    cout << " How many Order you want ?\n";
    cin >> data;
    for (int i = 0; i < data; i++) {

        cout << "enter the weekly menu food that you order " << i + 1 << endl;
        cin >> List[i].d_menu;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        cout << "enter the full name  " << i + 1 << endl;
        cin >> List[i].d_fullName;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        cout << " complain date of the food" << i + 1 << endl;
        cin >> List[i].d_date;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        cout << " food item ordered" << i + 1 << endl;
        cin >> List[i].d_item;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        cout << " complain description " << i + 1 << endl;
        cin >> List[i].d_complain;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        cout << "enter your contact number " << i + 1 << endl;
        cin >> List[i].d_contact;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        cout << "Enter your email address " << i + 1 << endl;
        cin >> List[i].d_email;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        ApplicantLunchOrdering << List[i].d_menu << "  " << List[i].d_fullName << "  " << List[i].d_date << "   " << List[i].d_item << "   "
            << List[i].d_complain << "   " << List[i].d_contact << "   " << List[i].d_email << "   " << endl;

        ApplicantLunchOrdering.close();
    }
}

void viewParentScreenData() {
    system("cls");

    fstream ApplicantLunchOrdering;
    ApplicantLunchOrdering.open("parentscreen.txt", ios::in);
    if (ApplicantLunchOrdering.is_open()) {
        string line;
        while (getline(ApplicantLunchOrdering, line)) {
            cout << line << endl;
        }
        ApplicantLunchOrdering.close();
    }

}





